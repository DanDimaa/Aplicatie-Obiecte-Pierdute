#pragma once
#include "requestsInterface.h"

class RequestFactory : public requestsInterface
{
private:
	std::string MesajPrimit;
	std::string MesajCedat;
public:
	RequestFactory(std::string MsgjPrimit= nullptr): MesajPrimit(MsgjPrimit) {}		//Constructor
	virtual ~RequestFactory() { MesajPrimit.clear();	MesajCedat.clear(); }		//Destructor


	//functii
	std::string Factory();
	//getter
	std::string getMesajPrimit() const override { return MesajPrimit; }
	std::string getMesajCedat() const override { return MesajCedat; }
};

