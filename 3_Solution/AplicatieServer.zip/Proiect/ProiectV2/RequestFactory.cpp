#include "RequestFactory.h"
#include "SignUp.h"
#include "Login.h"
#include "CreareAnunt.h"
#include "VizualizareToateAnunturile.h"
#include "VizualizareAnunMELE.h"
#include "UpdateStatusAnunt.h"
#include "VizualizareInbox.h"

std::string RequestFactory::Factory()
{
    SignUp* Sign_Up = nullptr;
    Login* Logging = nullptr;
    CreareAnunt* CreareA = nullptr;
    VizualizareToateAnunturile* ToateAnunturile = nullptr;
    VizualizareAnunMELE* AnunturileMele = nullptr;
    UpdateStatusAnunt* UpdateAnunt = nullptr;
    VizualizareInbox* Inbox = nullptr;

    if (this->MesajPrimit.length() > 0) {

        char IndexComanda = this->MesajPrimit[0];

        switch (IndexComanda) {
        case '1':
            Sign_Up = new SignUp(MesajPrimit);
            this->MesajCedat = Sign_Up->GetValidation();
            delete Sign_Up;
            break;

        case '2':
            Logging = new Login(MesajPrimit);
            this->MesajCedat = Logging->GetValidation();
            delete Logging;
            break;

        case '3':
            CreareA = new CreareAnunt(MesajPrimit);
            this->MesajCedat = CreareA->GetValidation();
            delete CreareA;
            break;

        case '4':
            ToateAnunturile = new VizualizareToateAnunturile();
            this->MesajCedat = ToateAnunturile->GetValidation();
            delete ToateAnunturile;
            break;

        case '5':
            AnunturileMele = new VizualizareAnunMELE(MesajPrimit);
            this->MesajCedat = AnunturileMele->GetValidation();
            delete AnunturileMele;
            break;

        case '6':
            UpdateAnunt = new UpdateStatusAnunt(MesajPrimit);
            this->MesajCedat = UpdateAnunt->GetValidation();
            delete UpdateAnunt;
            break;

        case '7':
            Inbox = new VizualizareInbox(MesajPrimit);
            this->MesajCedat = Inbox->GetValidation();
            delete Inbox;
            break;

        default:
            this->MesajCedat = "Comanda invalida";
            break;
        }
    }
    else
        MesajCedat = "Sir Gol";

    return MesajCedat;
}
