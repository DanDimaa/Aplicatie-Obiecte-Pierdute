﻿#include "VizualizareInbox.h"
#include <sstream>

void VizualizareInbox::DecriptMesaj()
{
    std::string Mesaj = MesajPrimit;
    std::istringstream iss(Mesaj);
    std::string word;

    std::getline(iss, word, '_');	//am extras optinea din string
    std::getline(iss, word, '_');	this->idClient = word;
    std::getline(iss, word, '_');
}

VizualizareInbox::~VizualizareInbox()
{
	idClient.clear();
	MesajPrimit.clear();
}

void VizualizareInbox::FetchNrInbox()
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT COUNT(*) FROM Inbox WHERE IdPropietar = ";
    query += std::wstring(idClient.begin(), idClient.end());
    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        SQLLEN count = 0;
        SQLBindCol(sqlStatementHandle, 1, SQL_C_LONG, &count, sizeof(count), NULL);

        SQLFetch(sqlStatementHandle);
        int tmp = count;
        this->nrInbox = std::to_string(tmp);
    }

    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);
}

std::string Sanitize(std::string X, size_t desiredSize) 
{
    for (int i = 0; i < desiredSize; i++) {
        if (X[i] == '\0') {
            X.erase(X.begin() + i, X.end());
            break;
        }
    }
    return X;
}

void VizualizareInbox::ConstruiesteSEND()
{
    this->MesajCedat += this->Msg + "_";
}

void VizualizareInbox::FetchInbox()
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT Mesaj FROM Inbox WHERE IdPropietar = ";
    query += std::wstring(idClient.begin(), idClient.end());

    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    size_t desiredSize = 40;

    int nr = stoi(nrInbox);
    for (int i = 0; i < nr; i++)
    {
        Msg.resize(desiredSize);

        retcode = SQLBindCol(sqlStatementHandle, 1, SQL_CHAR, &this->Msg[0], Msg.capacity(), NULL);

        retcode = SQLFetch(sqlStatementHandle);

        this->Msg = Sanitize(this->Msg, desiredSize);

        ConstruiesteSEND();

    }

}

std::string VizualizareInbox::GetValidation()
{
    //inserez in variabile
	DecriptMesaj();

    //iau nr anunturi
    FetchNrInbox();
    this->MesajCedat = nrInbox + "_";

    //fur Inbox
    FetchInbox();

    return MesajCedat;
    
}
