﻿#include "VizualizareToateAnunturile.h"
#include "DatabaseConnection.h"
#include <string>

void VizualizareToateAnunturile::ConstruiesteSEND()
{
	this->MesajCedat += this->Id + "_";
	this->MesajCedat += this->IdClient + "_";
	this->MesajCedat += this->Denumire + "_";
	this->MesajCedat += this->Detalii + "_";
	this->MesajCedat += this->DataPierdere + "_";
	this->MesajCedat += this->UltimaLocatie + "_";
}

std::string DesiredSize(std::string X, size_t desiredSize) {
    for (int i = 0; i < desiredSize; i++) {
        if (X[i] == '\0') {
            X.erase(X.begin() + i, X.end());
            break;
        }
    }
    return X;
}

void VizualizareToateAnunturile::FetchNrAnunturi()
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT COUNT(*) FROM Anunturi WHERE Stat= 'N';";

    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);
    
    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) 
    {
        SQLLEN count = 0;
        SQLBindCol(sqlStatementHandle, 1, SQL_C_LONG, &count, sizeof(count), NULL);

        SQLFetch(sqlStatementHandle);
        int tmp = count;
        this->NrAnunturi = std::to_string(tmp);
    }
    

    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);
}

void VizualizareToateAnunturile::FetchAnunturi()
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT ID, IdCont, Denumire, Detalii, DataPierdere, LastLocation FROM Anunturi WHERE Stat = 'N' ORDER BY DataPierdere DESC";

    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    size_t desiredSize = 40;

    int nr = std::stoi(NrAnunturi);
    for(int i = 0; i < nr ;i++) { 
        Id.resize(desiredSize);
        IdClient.resize(desiredSize);
        Denumire.resize(desiredSize);
        Detalii.resize(desiredSize);
        DataPierdere.resize(desiredSize);
        UltimaLocatie.resize(desiredSize);
        
        retcode = SQLBindCol(sqlStatementHandle, 1, SQL_CHAR, &this->Id[0], Id.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 2, SQL_CHAR, &this->IdClient[0], IdClient.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 3, SQL_CHAR, &this->Denumire[0], Denumire.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 4, SQL_CHAR, &this->Detalii[0], Detalii.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 5, SQL_CHAR, &this->DataPierdere[0], DataPierdere.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 6, SQL_CHAR, &this->UltimaLocatie[0], UltimaLocatie.capacity(), NULL);
        
        retcode = SQLFetch(sqlStatementHandle);

        this->Id = DesiredSize(this->Id, desiredSize);
        this->IdClient = DesiredSize(this->IdClient, desiredSize);
        this->Denumire = DesiredSize(this->Denumire, desiredSize);
        this->Detalii = DesiredSize(this->Detalii, desiredSize);
        this->DataPierdere = DesiredSize(this->DataPierdere, desiredSize);
        this->UltimaLocatie = DesiredSize(this->UltimaLocatie, desiredSize);

        ConstruiesteSEND();
    }

    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);
}

VizualizareToateAnunturile::~VizualizareToateAnunturile()
{
	NrAnunturi.clear();
	Id.clear();
	IdClient.clear();
	Denumire.clear();
	Detalii.clear();
	DataPierdere.clear();
	UltimaLocatie.clear();
}

std::string VizualizareToateAnunturile::GetValidation()
{
    //Fur nrAnunturi
    FetchNrAnunturi();

    this->MesajCedat = NrAnunturi + "_";

    //Fur Anunturile
    FetchAnunturi();

	return MesajCedat;
}
