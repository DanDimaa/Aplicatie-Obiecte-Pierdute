#pragma once
#include <iostream>
#include <string>
#include "DatabaseConnection.h"

class VizualizareInbox
{
	std::string idClient;
	std::string nrInbox;
	std::string Msg;

	std::string MesajPrimit;
	std::string MesajCedat;

	void DecriptMesaj();
	void FetchNrInbox();
	void FetchInbox();
	void ConstruiesteSEND();
public:
	VizualizareInbox(const std::string Msg) : MesajPrimit(Msg) {};
	virtual ~VizualizareInbox();

	//functii
	std::string GetValidation();
};

