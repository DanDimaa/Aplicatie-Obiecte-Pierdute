#pragma once
#include <iostream>
#include <string>
class requestsInterface
{
public:
	virtual ~requestsInterface() = default;
	virtual std::string getMesajPrimit() const = 0;
	virtual std::string getMesajCedat() const = 0;
};

