#pragma once
#include "DatabaseConnection.h"
#include <sstream>

class UpdateStatusAnunt
{
private:
	std::string IdAnunt;
	std::string IdContGasit;
	std::string IdProprietar;

	std::string MesajPrimit;

	void Decript();
	void insertInbox();
public:
	UpdateStatusAnunt(const std::string Msg) : MesajPrimit(Msg) {};
	virtual ~UpdateStatusAnunt();

	//functii
	std::string GetValidation();
};

