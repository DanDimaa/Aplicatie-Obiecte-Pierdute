﻿#include "CreareAnunt.h"
#include "DatabaseConnection.h"

#include <sstream>

void CreareAnunt::DecriptMesaj()
{
    std::string Mesaj = MesajPrimit;
    std::istringstream iss(Mesaj);
    std::string word;

    std::getline(iss, word, '_');	//am extras optinea din string
    std::getline(iss, word, '_');	this->IdClient = word;
    std::getline(iss, word, '_');	this->Denumire = word;
    std::getline(iss, word, '_');	this->UltimaLocatie = word;
    std::getline(iss, word, '_');	this->DataPierdere = word;
    std::getline(iss, word, '_');	this->Detalii = word;
}

std::string CreateAnunt(const std::string& IdClient, const std::string& Stat, const std::string& Denumire, const std::string& Detalii, const std::string& DataPierdere, const std::string& UltimaLocatie)
{
    // Obține handle-ul conexiunii la baza de date
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlconnectionhandle = dbConnection.getConnectionHandle();

    // Creează un nou handle pentru instrucțiunea SQL
    SQLHANDLE sqlstatementhandle;
    SQLRETURN retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

    // Construiește instrucțiunea SQL pentru inserarea anunțului
    std::wstring query = L"INSERT INTO Anunturi (idCont, Stat, Denumire, Detalii, DataPierdere, LastLocation) VALUES ('";
    query += std::wstring(IdClient.begin(),IdClient.end()) + L"', '";
    query += std::wstring(Stat.begin(), Stat.end()) + L"', '";
    query += std::wstring(Denumire.begin(), Denumire.end()) + L"', '";
    query += std::wstring(Detalii.begin(), Detalii.end()) + L"', '";
    query += std::wstring(DataPierdere.begin(), DataPierdere.end()) + L"', '";
    query += std::wstring(UltimaLocatie.begin(), UltimaLocatie.end()) + L"')";
    // Prepară instrucțiunea SQL
    retcode = SQLPrepare(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        // Bind parametrii la valorile specifice
        retcode = SQLBindParameter(sqlstatementhandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER, 0, 0, const_cast<char*>(IdClient.c_str()), 0, nullptr);
        retcode = SQLBindParameter(sqlstatementhandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 25, 0, const_cast<char*>(Stat.c_str()), 0, nullptr);
        retcode = SQLBindParameter(sqlstatementhandle, 3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 50, 0, const_cast<char*>(Denumire.c_str()), 0, nullptr);
        retcode = SQLBindParameter(sqlstatementhandle, 4, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 200, 0, const_cast<char*>(Detalii.c_str()), 0, nullptr);
        retcode = SQLBindParameter(sqlstatementhandle, 5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 10, 0, const_cast<char*>(DataPierdere.c_str()), 0, nullptr);
        retcode = SQLBindParameter(sqlstatementhandle, 6, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR, 100, 0, const_cast<char*>(UltimaLocatie.c_str()), 0, nullptr);

        // Execută instrucțiunea SQL
        retcode = SQLExecute(sqlstatementhandle);

        if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
        {
            // Inserarea a fost realizată cu succes
            return "Ok";
        }
        else
        {
            // A apărut o eroare la executarea instrucțiunii SQL
            return "Eroare la crearea anuntului.";
        }
    }
    SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);
}

CreareAnunt::~CreareAnunt()
{
	IdClient.clear();
	Stat.clear();
	Denumire.clear();
	Detalii.clear();
	DataPierdere.clear();
	UltimaLocatie.clear();

	MesajPrimit.clear();
}

std::string CreareAnunt::GetValidation()
{
    //Decriptam Mesajul  Primit
    DecriptMesaj();
    // Verifică dacă trigger-ul a fost declanșat și procesează outputul
    this->Stat = "N";
    return CreateAnunt(this->IdClient, this->Stat, this->Denumire, this->Detalii, this->DataPierdere, this->UltimaLocatie);

}
