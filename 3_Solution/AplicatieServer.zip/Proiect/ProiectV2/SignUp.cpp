﻿#include "SignUp.h"
#include <sstream>

#include <windows.h>
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>

#include <functional>

#include "DatabaseConnection.h"

std::string HashFunction(const std::string& password) {
    std::hash<std::string> hasher;
    size_t hash = hasher(password);
    return std::to_string(hash);
}

void InsertIntoConturi(const std::string& Nume, const std::string& Prenume, const std::string& Email, const std::string& Parola, const std::string& Grad, const std::string& Telefon)
{
    SQLHANDLE sqlconnectionhandle = DatabaseConnection::getInstance().getConnectionHandle();
    SQLHANDLE sqlstatementhandle;
    SQLRETURN retcode;

    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

    std::wstring query = L"INSERT INTO Conturi (Nume, Prenume, Email, Parola, Grad, Telefon) VALUES ('";
    query += std::wstring(Nume.begin(), Nume.end()) + L"', '";
    query += std::wstring(Prenume.begin(), Prenume.end()) + L"', '";
    query += std::wstring(Email.begin(), Email.end()) + L"', '";
    query += std::wstring(Parola.begin(), Parola.end()) + L"', '";
    query += std::wstring(Grad.begin(), Grad.end()) + L"', '";
    query += std::wstring(Telefon.begin(), Telefon.end()) + L"')";

    retcode = SQLExecDirect(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);
}

bool CheckIfClientExists(const std::string& Email)
{
    // Obțineți instanța singleton-ului DatabaseConnection
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlconnectionhandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlstatementhandle;
    SQLRETURN retcode;

    bool exists = false;

    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

    // Construirea instrucțiunii SQL de verificare
    std::wstring query = L"SELECT COUNT(*) FROM Conturi WHERE Email = '";
    query += std::wstring(Email.begin(), Email.end()) + L"'";

    retcode = SQLExecDirect(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {
        SQLLEN count = 0;
        SQLBindCol(sqlstatementhandle, 1, SQL_C_LONG, &count, sizeof(count), NULL);

        if (SQLFetch(sqlstatementhandle) == SQL_SUCCESS) {
            if (count > 0) {
                exists = true;
            }
        }
    }

    SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);

    return exists;
}

int SignUp::ValidateMesaj()
{
	std::string Mesaj = MesajPrimit;
	int numarCaractere = 0;
	for (char caracter : Mesaj) {
		if (caracter == '_') {
			numarCaractere++;
		}
	}
	return numarCaractere;
}   //Nu mai este necesara

void SignUp::DecriptMesaj()
{
	std::string Mesaj = MesajPrimit;
	std::istringstream iss(Mesaj);
	std::string word;

	std::getline(iss, word, '_');	//am extras optinea din string
	std::getline(iss, word, '_');	this->Nume		= word;
	std::getline(iss, word, '_');	this->Prenume	= word;
	std::getline(iss, word, '_');	this->Email		= word;

    std::string TmpPass;
	std::getline(iss, word, '_');	TmpPass	= word;
    this->Parola = HashFunction(TmpPass);

	std::getline(iss, word, '_');	this->Grad		= word;
	std::getline(iss, word, '_');	this->Telefon	= word;

}

SignUp::~SignUp()
{
	Nume.clear();
	Prenume.clear();
	Email.clear();
	Parola.clear();
	Grad.clear();
	Telefon.clear();
}

std::string SignUp::GetValidation()
{

	DecriptMesaj();

	//Verif Date din BAZA de date
    if (CheckIfClientExists(Email)) {
        return "Eroare: Utilizatorul deja exista!";
    }
    else 
        InsertIntoConturi(Nume, Prenume, Email, Parola, Grad, Telefon);

	return "Ok";  //Sign Up Success
}
