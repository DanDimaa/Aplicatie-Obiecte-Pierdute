#pragma once
#include <iostream>
#include <string>

class VizualizareToateAnunturile
{
private:
	std::string NrAnunturi;

	std::string Id;
	std::string IdClient;
	std::string Denumire;
	std::string Detalii;
	std::string DataPierdere;
	std::string UltimaLocatie;

	std::string MesajCedat;

	void ConstruiesteSEND();
	void FetchNrAnunturi();
	void FetchAnunturi();
public:
	VizualizareToateAnunturile() {};
	virtual ~VizualizareToateAnunturile();

	//functii
	std::string GetValidation();
};

