#pragma once
#include <iostream>
#include <string>

class Login
{
private:
	std::string MesajPrimit;
	std::string MesajCedat;

	int ID;
	std::string Nume;
	std::string Prenume;
	std::string Email;
	std::string Grad;
	std::string Telefon;

	std::string Parola;

	void selectConturi(std::string,std::string);

	void DecriptMesaj();
	std::string ReturnMesaj();
public:
	Login(std::string Msg) : MesajPrimit(Msg) {};
	virtual ~Login();

	//functii
	std::string GetValidation();
};

