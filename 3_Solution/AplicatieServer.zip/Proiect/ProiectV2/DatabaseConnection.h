﻿#pragma once
#include <iostream>
#include <string>
#include <windows.h>
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>

class DatabaseConnection {
private:
    SQLHANDLE sqlconnectionhandle;  //ODBC (Open Database Connectivity).
    SQLHANDLE sqlenvhandle;
    DatabaseConnection() {
        // Inițializarea conexiunii la baza de date
        SQLRETURN retcode;
        retcode = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlenvhandle);
        retcode = SQLSetEnvAttr(sqlenvhandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0);
        retcode = SQLAllocHandle(SQL_HANDLE_DBC, sqlenvhandle, &sqlconnectionhandle);
        retcode = SQLDriverConnectW(sqlconnectionhandle, NULL, (SQLWCHAR*)L"DRIVER={SQL Server};SERVER=DESKTOP-JF2QEE0;DATABASE=Aplicatie Obiecte Pierdute;Trusted_Connection=yes;", SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

        if (retcode != SQL_SUCCESS && retcode != SQL_SUCCESS_WITH_INFO) {
            // Tratarea erorilor de conectare
            std::cout << "Conexiunea la baza de date a esuat!" << std::endl;
        }
        else std::cout << " Poti Incepe Magia!!" << std::endl;
    }

public:
    static DatabaseConnection& getInstance() {
        static DatabaseConnection instance;
        return instance;
    }

    SQLHANDLE getConnectionHandle() {
        return sqlconnectionhandle;
    }

    ~DatabaseConnection() {
        // Eliberarea resurselor și deconectarea de la baza de date
        SQLDisconnect(sqlconnectionhandle);
        SQLFreeHandle(SQL_HANDLE_DBC, sqlconnectionhandle);
        SQLFreeHandle(SQL_HANDLE_ENV, sqlenvhandle);
    }
};
