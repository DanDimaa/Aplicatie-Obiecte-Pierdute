#include "UpdateStatusAnunt.h"

void UpdateStatusAnunt::Decript()
{
	std::string Mesaj = MesajPrimit;
	std::istringstream iss(Mesaj);
	std::string word;

	std::getline(iss, word, '_');	//am extras optinea din string
	std::getline(iss, word, '_');	this->IdAnunt = word;
	std::getline(iss, word, '_');	this->IdContGasit = word;
	std::getline(iss, word, '_');	this->IdProprietar = word;
	std::getline(iss, word, '_');
}

void UpdateStatusAnunt::insertInbox()
{
	SQLHANDLE sqlconnectionhandle = DatabaseConnection::getInstance().getConnectionHandle();
	SQLHANDLE sqlstatementhandle;
	SQLRETURN retcode;

	retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

	std::wstring query = L"INSERT INTO Inbox (IdAnunt, IdContGasit, IdPropietar) VALUES ('";
	query += std::wstring(IdAnunt.begin(), IdAnunt.end()) + L"', '";
	query += std::wstring(IdContGasit.begin(), IdContGasit.end()) + L"', '";
	query += std::wstring(IdProprietar.begin(), IdProprietar.end()) + L"')";

	retcode = SQLExecDirect(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

	SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);
}

void UpdateAnunt(const std::string& IdAnunt)
{
	SQLHANDLE sqlconnectionhandle = DatabaseConnection::getInstance().getConnectionHandle();
	SQLHANDLE sqlstatementhandle;
	SQLRETURN retcode;

	retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

	std::wstring query = L"UPDATE Anunturi SET Stat = 'G' WHERE ID = ";
	query += std::wstring(IdAnunt.begin(), IdAnunt.end());

	retcode = SQLExecDirect(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

	SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);
}

UpdateStatusAnunt::~UpdateStatusAnunt()
{
	IdAnunt.clear();
	IdContGasit.clear();
	IdProprietar.clear();

	MesajPrimit.clear();
}

std::string UpdateStatusAnunt::GetValidation()
{
	Decript();

	UpdateAnunt(this->IdAnunt);
	insertInbox();
	return "Ok";
}
