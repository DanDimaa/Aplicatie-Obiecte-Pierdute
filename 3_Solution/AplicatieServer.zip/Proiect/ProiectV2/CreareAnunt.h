#pragma once
#include <iostream>
#include <string>

class CreareAnunt
{
private:
	std::string IdClient;
	std::string Stat;
	std::string Denumire;
	std::string Detalii;
	std::string DataPierdere;
	std::string UltimaLocatie;

	std::string MesajPrimit;
	
	void DecriptMesaj();
public:
	CreareAnunt(const std::string Msg) : MesajPrimit(Msg) {};
	virtual ~CreareAnunt();

	//functii
	std::string GetValidation();
};

