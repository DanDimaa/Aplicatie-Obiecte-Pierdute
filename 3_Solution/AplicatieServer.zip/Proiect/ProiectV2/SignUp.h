#pragma once
#include <iostream>
#include <string>

class SignUp
{
private:
	std::string MesajPrimit;

	std::string Nume;
	std::string Prenume;
	std::string Email;
	std::string Parola;
	std::string Grad;
	std::string Telefon;

	//functii private
	int ValidateMesaj();
	void DecriptMesaj();

public:
	SignUp(std::string MsgPrimit = nullptr) : MesajPrimit(MsgPrimit) { };
	virtual ~SignUp();

	//functii
	std::string GetValidation();
};

