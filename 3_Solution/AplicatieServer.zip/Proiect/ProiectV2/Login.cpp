﻿#include "Login.h"
#include <sstream>

#include <windows.h>
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>

#include <functional>

#include "DatabaseConnection.h"

std::string HashFunction1(const std::string& password) {
    std::hash<std::string> hasher;
    size_t hash = hasher(password);
    return std::to_string(hash);
}

void Login::DecriptMesaj()
{
	std::string Mesaj = MesajPrimit;
	std::istringstream iss(Mesaj);
	std::string word;

	std::getline(iss, word, '_');	//am extras optinea din string
	std::getline(iss, word, '_');	this->Email = word;

    std::string TmpPass;
	std::getline(iss, word, '_');	TmpPass = word;
    this->Parola = HashFunction1(TmpPass);
}

std::string Login::ReturnMesaj()
{
    std::string idN = std::to_string(this->ID);
    
    std::string MrPoseidon = "2_" + idN;
    MrPoseidon += "_" + this->Nume;
    MrPoseidon += "_" + this->Prenume;
    MrPoseidon += "_" + this->Email;
    MrPoseidon += "_" + this->Grad;
    MrPoseidon += "_" + this->Telefon;
    MrPoseidon += "_";
    return MrPoseidon;
}

Login::~Login()
{
	MesajPrimit.clear();
	MesajCedat.clear();

    ID = 0;
    Nume.clear();
    Prenume.clear();
	Email.clear();
	Grad.clear();
	Telefon.clear();

	Parola.clear();
}

bool VerificaCredentiale(const std::string& Email, const std::string& Parola)
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlconnectionhandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlstatementhandle = NULL;
    SQLRETURN retcode;

    bool exists = false;

    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlconnectionhandle, &sqlstatementhandle);

    // Construirea instrucțiunii SQL de verificare
    std::wstring query = L"SELECT COUNT(*) FROM Conturi WHERE Email = '";
    query += std::wstring(Email.begin(), Email.end()) + L"' AND Parola = '";
    query += std::wstring(Parola.begin(), Parola.end()) + L"'";

    retcode = SQLExecDirect(sqlstatementhandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) {
        SQLLEN count = 0;
        SQLBindCol(sqlstatementhandle, 1, SQL_C_LONG, &count, sizeof(count), NULL);

        if (SQLFetch(sqlstatementhandle) == SQL_SUCCESS) {
            if (count > 0) {
                exists = true;
            }
        }
    }

    SQLFreeHandle(SQL_HANDLE_STMT, sqlstatementhandle);
    return exists;
}

void Login::selectConturi(std::string Email, std::string Parola) {
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT ID, Nume, Prenume, Email, Grad, Telefon FROM Conturi WHERE Email = '";
    query += std::wstring(Email.begin(), Email.end()) + L"' AND Parola = '";
    query += std::wstring(Parola.begin(), Parola.end()) + L"'";

    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    // Obținerea rezultatului interogării
    size_t desiredSize = 40;

    Nume.resize(desiredSize);
    Prenume.resize(desiredSize);
    Telefon.resize(desiredSize);
    Grad.resize(desiredSize);


    retcode = SQLBindCol(sqlStatementHandle, 1, SQL_INTEGER, &this->ID, sizeof(this->ID), NULL);
    retcode = SQLBindCol(sqlStatementHandle, 2, SQL_CHAR, &this->Nume[0], Nume.capacity(), NULL);
    retcode = SQLBindCol(sqlStatementHandle, 3, SQL_CHAR, &this->Prenume[0], Prenume.capacity(), NULL);
    retcode = SQLBindCol(sqlStatementHandle, 5, SQL_CHAR, &this->Grad[0], Grad.capacity(), NULL);
    retcode = SQLBindCol(sqlStatementHandle, 6, SQL_CHAR, &this->Telefon[0], Telefon.capacity(), NULL);

    retcode = SQLFetch(sqlStatementHandle);


    for (int i = 0; i < desiredSize; i++) {
        if (this->Nume[i] == '\0') {
            Nume.erase(Nume.begin() + i, Nume.end());
            break;
        }
    }
    for (int i = 0; i < desiredSize; i++) {
        if (this->Prenume[i] == '\0') {
            Prenume.erase(Prenume.begin() + i, Prenume.end());
            break;
        }
    }
    for (int i = 0; i < desiredSize; i++) {
        if (this->Grad[i] == '\0') {
            Grad.erase(Grad.begin() + i, Grad.end());
            break;
        }
    }
    for (int i = 0; i < desiredSize; i++) {
        if (this->Telefon[i] == '\0') {
            Telefon.erase(Telefon.begin() + i, Telefon.end());
            break;
        }
    }


    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);

}

std::string Login::GetValidation() {

    DecriptMesaj();

    if (VerificaCredentiale(Email, Parola)) {
        //FurtBaza de Date!!!
        selectConturi(Email,Parola);
        //Creare MesajCedat
        return ReturnMesaj();  // Success Login
    }
    else
        return "Nume sau parola gresita!_"; //Eroare: Credențiale invalide
}
