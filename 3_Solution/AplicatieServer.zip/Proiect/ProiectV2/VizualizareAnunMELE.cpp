﻿#include "VizualizareAnunMELE.h"
#include <sstream>

void VizualizareAnunMELE::Decodifica()
{
    std::string Mesaj = MesajPrimit;
    std::istringstream iss(Mesaj);
    std::string word;

    std::getline(iss, word, '_');	//am extras optinea din string
    std::getline(iss, word, '_');	this->IdClient = word;
    std::getline(iss, word, '_');	
}

void VizualizareAnunMELE::ConstruiesteSEND()
{
	this->MesajCedat += this->Id + "_";
	this->MesajCedat += this->IdClient + "_";
	this->MesajCedat += this->Denumire + "_";
	this->MesajCedat += this->Detalii + "_";
	this->MesajCedat += this->DataPierdere + "_";
	this->MesajCedat += this->UltimaLocatie + "_";
}

std::string DesiredSizet(std::string X, size_t desiredSize) {
    for (int i = 0; i < desiredSize; i++) {
        if (X[i] == '\0') {
            X.erase(X.begin() + i, X.end());
            break;
        }
    }
    return X;
}

void VizualizareAnunMELE::FetchNrAnunturi()
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT COUNT(*) FROM Anunturi WHERE Stat= 'N' AND IdCont = ";
    query += std::wstring(IdClient.begin(), IdClient.end());
    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO)
    {
        SQLLEN count = 0;
        SQLBindCol(sqlStatementHandle, 1, SQL_C_LONG, &count, sizeof(count), NULL);

        SQLFetch(sqlStatementHandle);
        int tmp = count;
        this->NrAnunturi = std::to_string(tmp);
    }


    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);
}

void VizualizareAnunMELE::FetchAnunturileMele(const std::string& IdClient)
{
    DatabaseConnection& dbConnection = DatabaseConnection::getInstance();
    SQLHANDLE sqlConnectionHandle = dbConnection.getConnectionHandle();
    SQLHANDLE sqlStatementHandle = SQL_NULL_HANDLE;
    SQLRETURN retcode;

    // Construirea interogării SQL pentru selectarea datelor dorite
    std::wstring query = L"SELECT ID, IdCont, Denumire, Detalii, DataPierdere, LastLocation FROM Anunturi WHERE Stat = 'N' AND IdCont = ";
    query += std::wstring(IdClient.begin(), IdClient.end());
    query += L" ORDER BY DataPierdere DESC";

    // Executarea interogării
    retcode = SQLAllocHandle(SQL_HANDLE_STMT, sqlConnectionHandle, &sqlStatementHandle);
    retcode = SQLExecDirect(sqlStatementHandle, (SQLWCHAR*)query.c_str(), SQL_NTS);

    size_t desiredSize = 40;

    int nr = std::stoi(NrAnunturi);
    for (int i = 0; i < nr; i++) {
        Id.resize(desiredSize);
        Denumire.resize(desiredSize);
        Detalii.resize(desiredSize);
        DataPierdere.resize(desiredSize);
        UltimaLocatie.resize(desiredSize);

        retcode = SQLBindCol(sqlStatementHandle, 1, SQL_CHAR, &this->Id[0], Id.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 3, SQL_CHAR, &this->Denumire[0], Denumire.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 4, SQL_CHAR, &this->Detalii[0], Detalii.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 5, SQL_CHAR, &this->DataPierdere[0], DataPierdere.capacity(), NULL);
        retcode = SQLBindCol(sqlStatementHandle, 6, SQL_CHAR, &this->UltimaLocatie[0], UltimaLocatie.capacity(), NULL);

        retcode = SQLFetch(sqlStatementHandle);

        this->Id = DesiredSizet(this->Id, desiredSize);
        this->Denumire = DesiredSizet(this->Denumire, desiredSize);
        this->Detalii = DesiredSizet(this->Detalii, desiredSize);
        this->DataPierdere = DesiredSizet(this->DataPierdere, desiredSize);
        this->UltimaLocatie = DesiredSizet(this->UltimaLocatie, desiredSize);

        ConstruiesteSEND();
    }

    SQLFreeHandle(SQL_HANDLE_STMT, sqlStatementHandle);
    SQLFreeHandle(SQL_HANDLE_DBC, sqlConnectionHandle);
}

VizualizareAnunMELE::~VizualizareAnunMELE()
{
	NrAnunturi.clear();
	Id.clear();
	IdClient.clear();
	Denumire.clear();
	Detalii.clear();
	DataPierdere.clear();
	UltimaLocatie.clear();

	MesajPrimit.clear();
}

std::string VizualizareAnunMELE::GetValidation()
{
    //Decodific
    Decodifica();

    //FurnrAnunturi
    FetchNrAnunturi();

    this->MesajCedat = NrAnunturi + "_";

    //Selectez Anunturile asociate cu IdUl Contului
    FetchAnunturileMele(IdClient);

    return MesajCedat;
}
