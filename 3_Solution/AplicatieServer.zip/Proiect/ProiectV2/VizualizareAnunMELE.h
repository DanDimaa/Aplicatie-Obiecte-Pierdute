#pragma once
#include "DatabaseConnection.h"

class VizualizareAnunMELE
{
private:
	std::string NrAnunturi;

	std::string Id;
	std::string IdClient;
	std::string Denumire;
	std::string Detalii;
	std::string DataPierdere;
	std::string UltimaLocatie;


	std::string MesajCedat;
	std::string MesajPrimit;

	void Decodifica();

	void ConstruiesteSEND();
	void FetchNrAnunturi();
	void FetchAnunturileMele(const std::string&);
public:
	VizualizareAnunMELE(const std::string msg) :MesajPrimit(msg) {};
	virtual ~VizualizareAnunMELE();

	//functii
	std::string GetValidation();
};

