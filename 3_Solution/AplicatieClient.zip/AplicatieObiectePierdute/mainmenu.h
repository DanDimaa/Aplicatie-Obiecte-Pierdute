#ifndef MAINMENU_H
#define MAINMENU_H

#include <QDialog>
#include "mainwindow.h"

namespace Ui {
class MainMenu;
}

class MainMenu : public QDialog
{
    Q_OBJECT

public:
    explicit MainMenu(MainWindow* pa,CUser* pu, QWidget *parent = nullptr);
    ~MainMenu();

    CUser*& getUser() {return user;}

private slots:
    void on_returnButton_clicked();

    void on_createButton_clicked();

    void on_anunturiButton_clicked();

    void on_anunturileMeleButton_clicked();

    void on_inboxButton_clicked();

private:
    Ui::MainMenu *ui;

    CUser*          user;
    MainWindow*     parent;
};

#endif // MAINMENU_H
