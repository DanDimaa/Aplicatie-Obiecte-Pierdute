#include "announcementswindow.h"
#include "ui_announcementswindow.h"
#include <QRadioButton>
#include <QScrollArea>
#include <QLabel>
#include <QTextEdit>



announcementsWindow::announcementsWindow(std::vector<CAd*> adds, MainMenu* pm, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::announcementsWindow)
{
    this->_adds = adds;
    this->_menu=pm;
    ui->setupUi(this);

    this->scrollArea=ui->scrollArea;
    QWidget *scrollWidget = new QWidget(scrollArea);
    QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);
    scrollWidget->setLayout(scrollLayout);
    scrollArea->setWidget(scrollWidget);
    scrollArea->setWidgetResizable(true);

    // Adăugați rândurile în QScrollArea
    for (int i = 0; i < _adds.size(); ++i) {

        QHBoxLayout *rowLayout = new QHBoxLayout();
        QRadioButton *radioButton = new QRadioButton();
        QLabel *label1 = new QLabel(_adds[i]->getDen());
        QLabel *label2 = new QLabel(_adds[i]->getLoc());
        QLabel *label3 = new QLabel(_adds[i]->getDate());
        QTextEdit *textEdit = new QTextEdit(_adds[i]->getDesc());


        radioButtonList.push_back(radioButton);
        rowLayout->addWidget(radioButton);
        rowLayout->addWidget(label1);
        rowLayout->addWidget(label2);
        rowLayout->addWidget(label3);
        rowLayout->addWidget(textEdit);

        qDebug() << rowLayout;

        scrollLayout->addLayout(rowLayout);
    }
}

announcementsWindow::~announcementsWindow()
{
    int var = _adds.size();
    for(int i=0; i<var; i++)
        delete _adds[i];


    delete ui;
}

void announcementsWindow::on_returnButton_clicked()
{
    close();
    this->_menu->show();

    delete this;
}


void announcementsWindow::on_confirmButton_clicked()
{
    for (int i=0; i<_adds.size(); i++)
    {
        if(radioButtonList[i]->isChecked())
        {
            QString     send = "6_"+QString::number(this->_adds[i]->getId())+"_"+QString::number(this->_menu->getUser()->getId())+"_"+QString::number(this->_adds[i]->getIdUser())+"_";
            QByteArray  tmp=send.toUtf8();
            char*       sendbuff=tmp.data();
            QString recv = ConnectionSocket::getInstance()->connectServer(sendbuff);

            if(recv[0]=='O' && recv[1]=='k')
            {
                close();
                this->_menu->show();

                delete this;
            }
        }
    }
}

