#ifndef INBOXWINDOW_H
#define INBOXWINDOW_H

#include <QDialog>
#include "mainmenu.h"
#include <QScrollArea>
#include <QRadioButton>
#include <QScrollArea>
#include <QLabel>
#include <QTextEdit>
#include <QVBoxLayout>

namespace Ui {
class inboxWindow;
}

class inboxWindow : public QDialog
{
    Q_OBJECT

public:
    explicit inboxWindow(MainMenu* pm,QVector<QString> msg ,QWidget *parent = nullptr);
    ~inboxWindow();

private slots:
    void on_returnButton_clicked();

private:
    MainMenu*       _menu;
    Ui::inboxWindow *ui;
    QVector<QString> _msg;
    QScrollArea* _scrollArea;
};

#endif // INBOXWINDOW_H
