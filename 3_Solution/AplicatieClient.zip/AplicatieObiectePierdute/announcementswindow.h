#ifndef ANNOUNCEMENTSWINDOW_H
#define ANNOUNCEMENTSWINDOW_H

#include <QDialog>
#include "mainmenu.h"
#include <QVBoxLayout>
#include <QToolButton>
#include "cad.h"
#include <iostream>
#include <vector>
#include <QRadioButton>
#include <QScrollArea>
#include <QLabel>
#include <QTextEdit>


namespace Ui {
class announcementsWindow;
}

class announcementsWindow : public QDialog
{
    Q_OBJECT

public:
    explicit announcementsWindow(std::vector<CAd*> adds, MainMenu* pm, QWidget *parent = nullptr);
    ~announcementsWindow();

private slots:
    void on_returnButton_clicked();

    void on_confirmButton_clicked();

private:
    Ui::announcementsWindow *ui;
    std::vector<CAd*> _adds;
    MainMenu*   _menu;
    QScrollArea* scrollArea;
    QList<QRadioButton*> radioButtonList;

};

#endif // ANNOUNCEMENTSWINDOW_H
