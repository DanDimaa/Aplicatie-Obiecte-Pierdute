
#ifndef CUSER_H
#define CUSER_H
#include <iostream>
using namespace std;
#include <QString>



class CUser
{
    int         _id;
    QString      _email;
    QString      _name;
    QString      _lastname;
    QString     _phone;
    QString      _grad;


public:
    CUser() {};
    CUser(int id, QString email, QString name, QString lastname, QString phone, QString grad) : _id(id), _email(email), _name(name), _lastname(lastname),
                                                                                                                _phone(phone), _grad(grad) {}
    QString getFullname() { return _name + " " + _lastname; }
    int     getId() {   return  _id;    }
};

#endif // CUSER_H
