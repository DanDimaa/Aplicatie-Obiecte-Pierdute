#ifndef CREATEWINDOW_H
#define CREATEWINDOW_H

#include <QDialog>
#include "mainmenu.h"

namespace Ui {
class createWindow;
}

class createWindow : public QDialog
{
    Q_OBJECT

public:
    explicit createWindow(MainMenu* p, QWidget *parent = nullptr);
    ~createWindow();

private slots:
    void on_returnButton_clicked();

    void on_createAddButton_clicked();

private:
    MainMenu*        _menu;
    Ui::createWindow *ui;
};

#endif // CREATEWINDOW_H
