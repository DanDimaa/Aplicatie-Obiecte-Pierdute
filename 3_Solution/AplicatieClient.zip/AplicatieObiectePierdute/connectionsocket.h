
#ifndef CONNECTIONSOCKET_H
#define CONNECTIONSOCKET_H
#define WIN32_LEAN_AND_MEAN

#include <iostream>
using namespace std;

#include<string>
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <QString>



class ConnectionSocket
{
    static ConnectionSocket* instance;
    ConnectionSocket() {}
    ConnectionSocket(ConnectionSocket& obj) {}
    ~ConnectionSocket() {}
public:
    static ConnectionSocket* getInstance();
    QString connectServer(char* sendbuff);
};

#endif // CONNECTIONSOCKET_H
