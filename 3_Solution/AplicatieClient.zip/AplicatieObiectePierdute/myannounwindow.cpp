#include "myannounwindow.h"
#include "ui_myannounwindow.h"

myannounwindow::myannounwindow(std::vector<CAd*> adds, MainMenu* pm, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::myannounwindow)
{
    this->_adds = adds;
    this->_menu=pm;
    ui->setupUi(this);

    this->scrollArea=ui->scrollArea;
    QWidget *scrollWidget = new QWidget(scrollArea);
    QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);
    scrollWidget->setLayout(scrollLayout);
    scrollArea->setWidget(scrollWidget);
    scrollArea->setWidgetResizable(true);

    // Adăugați rândurile în QScrollArea
    for (int i = 0; i < _adds.size(); ++i) {

        QHBoxLayout *rowLayout = new QHBoxLayout();
        QLabel *label1 = new QLabel(_adds[i]->getDen());
        QLabel *label2 = new QLabel(_adds[i]->getLoc());
        QLabel *label3 = new QLabel(_adds[i]->getDate());
        QTextEdit *textEdit = new QTextEdit(_adds[i]->getDesc());

        rowLayout->addWidget(label1);
        rowLayout->addWidget(label2);
        rowLayout->addWidget(label3);
        rowLayout->addWidget(textEdit);

        qDebug() << rowLayout;

        scrollLayout->addLayout(rowLayout);
    }
}

myannounwindow::~myannounwindow()
{
    delete ui;
}

void myannounwindow::on_returnButton_clicked()
{
    close();
    this->_menu->show();

    delete this;
}

