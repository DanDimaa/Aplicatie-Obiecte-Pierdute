
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "signupwindow.h"
#include "mainmenu.h"
#include <QTime>


void delay(int secs)
{
    QTime dieTime= QTime::currentTime().addSecs(secs);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setMinimumSize(980,980);
    this->setMaximumSize(980,980);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool isGoodEmail1(QString email, QString suffix)
{
    if(email.length() < suffix.length())
        return false;

    int     n1 = email.length();
    int     n2 = suffix.length();


    for(int i=0; i< n2 ; i++)

        if(email[n1-i-1]!=suffix[n2-i-1])
            return false;

    return true;
}

void MainWindow::on_signinButton_clicked()
{
    QString     email = ui->lineEmail->text();
    QString     pass = ui->linePass->text();
    ui->labelInf->clear();


    if(email == "dima" && pass == "dima")
    {
        QString     send = "2_"+email+"_"+pass+"_";
        QByteArray  tmp=send.toUtf8();
        char*       sendbuff=tmp.data();

        QString     recv;


        ui->labelInf->setText("<font color='green'>Conectare reusita!</font>");
        delay(2);



        ui->labelInf->clear();
        ui->lineEmail->clear();
        ui->linePass->clear();

        CUser*      user=new CUser(1, "dima", "Dima", "Dan", "0729953934", "Student");

        MainMenu* mainmenuWindow = new MainMenu(this, user);
        close();
        mainmenuWindow->show();

    }

    if(isGoodEmail1(email, "@mta.ro"))
    {
        QString send = "2_"+email+"_"+pass+"_";
        QByteArray  tmp = send.toUtf8();
        char*       sendbuff=tmp.data();
        QString recv = ConnectionSocket::getInstance()->connectServer(sendbuff);

        //de facut sanitize la input


        if(recv[0]!='2')
        {
            QStringList list = recv.split("_");
            ui->labelInf->setText("<font color='red'>"+list[0]+"</font>");
        }
            else
        {
            QStringList list=recv.split("_");

            int         id=list[1].toInt();
            QString     name=list[2];
            QString     lastname=list[3];
            QString     email=list[4];
            QString     grad=list[5];
            QString     phone=list[6];


            CUser* user=new CUser(id, email, name, lastname, phone, grad);

            ui->labelInf->setText("<font color='green'>Conectare reusita!</font>");
            delay(2);

            ui->lineEmail->setText("");
            ui->linePass->setText("");
            ui->labelInf->setText("");
            MainMenu* mainmenuWindow = new MainMenu(this, user);
            close();
            mainmenuWindow->show();
        }
    }
    else
    {
        ui->labelInf->setText("<font color='red'>Introduceti adresa de mail institutionala!</font>");
    }



}


void MainWindow::on_signupButton_clicked()
{
    SignUpWindow    *signupWindow = new SignUpWindow(this);
    this->close();
    signupWindow->show();
}

