
#ifndef CAD_H
#define CAD_H
#include <iostream>
#include <QString>
using namespace std;



class CAd
{
    int     _id;
    QString _den;
    QString _location;
    QString _description;
    QString _data;

    int     _idUser;



public:
    CAd(int id, QString den, QString location, QString description, int idUser, QString data) : _id(id), _den(den), _location(location), _description(description), _idUser(idUser), _data(data){}
    QString getDen() { return _den; }
    QString getLoc() { return _location; }
    QString getDesc() { return _description; }
    QString getDate() { return _data; }
    int     getId() { return _id; }
    int     getIdUser() { return _idUser; }
};

#endif // CAD_H
