#include "signupwindow.h"
#include "ui_signupwindow.h"

#include <QDebug>
#include <QTime>

SignUpWindow::SignUpWindow(MainWindow* par, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SignUpWindow)
{
    this->parent = par;
    ui->setupUi(this);
    this->setWindowTitle("Sign Up Window");
}

SignUpWindow::~SignUpWindow()
{
    delete ui;
}

bool isTheSamePass(QString pass, QString confPass)
{

    if(pass.length() != confPass.length())
        return false;

    for(int i=0; i<pass.length(); i++)
        if(pass[i] != confPass[i])
            return false;

    return true;

}

bool isGoodEmail(QString email, QString suffix)
{
    if(email.length() < suffix.length())
        return false;

    int     n1 = email.length();
    int     n2 = suffix.length();


    for(int i=0; i< n2 ; i++)

        if(email[n1-i-1]!=suffix[n2-i-1])
            return false;

    return true;
}

void delay1(int secs)
{
    QTime dieTime= QTime::currentTime().addSecs(secs);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}


void SignUpWindow::on_pushButton_clicked()
{
    QString     email = ui->lineEmail->text();
    QString     pass = ui->linePass->text();
    QString     confPass = ui->lineConfirmPass->text();
    QString     name = ui->lineName->text();
    QString     lastname = ui->lineLastName->text();
    QString     phone = ui->lineTelefon->text();
    bool        ready = true;
    ui->labelInf->setText("");

    if(email.length() == 0 || pass.length() == 0 || confPass.length() == 0 || name.length() == 0 || lastname.length() == 0)
    {
        ui->labelInf->setText("<font color='red'>Introduceti toate datele!</font>");
        ready = false;
    }
    if(ready)
    {

        if(!(name[0]>='A' && name[0]<='Z') && name.length()>0 )
        {
            ui->labelInf->setText("<font color='red'>Numele trebuie sa inceapa cu litera mare!</font>");
            ready=false;
        }

        if(!(lastname[0]>='A' && lastname[0]<='Z') && lastname.length()>0)
        {
            ui->labelInf->setText("<font color='red'>Prenumele trebuie sa inceapa cu litera mare!</font>");
            ready=false;
        }

        if(!isGoodEmail(email, "@mta.ro") && email.length() > 0)
        {
            ui->labelInf->setText("<font color='red'>Adresa de email trebuie sa fie cea institutionala!</font>");
            ready = false;
        }

        if(!isTheSamePass(pass, confPass))
        {
            ui->labelInf->setText("<font color='red'>Eroare la confirmarea parolei!</font>");
            ready = false;
        }
        if((phone[0]!='0' && phone[1]!='7') || phone.length()<10)
        {
            ui->labelInf->setText("<font color='red'>Formatul telefonului nu este bun</font>");
        }

    }

    QString     grad;
    if(ui->radioStudent->isChecked())
        grad = "Std";
    if(ui->radioFruntas->isChecked())
        grad = "Frt";
    if(ui->radioSergent->isChecked())
        grad = "Sg";
    if(ui->radioSgMaj->isChecked())
        grad = "SgMaj";
    if(ui->radioPlt->isChecked())
        grad = "Plt";
    if(ui->radioPltMaj->isChecked())
        grad = "PltMaj";
    if(ui->radioPltAdj->isChecked())
        grad = "PltAdj";
    if(ui->radioPltAdjPr->isChecked())
        grad = "PltAdjPr";
    if(ui->radioCaporal->isChecked())
        grad="Cap";

    if(grad.length()==0)
    {
        ui->labelInf->setText("<font color='red'>Alege-ti gradul!!</font>");
        ready = false;
    }

    if(email.length() == 0 || pass.length() == 0 || confPass.length() == 0 || name.length() == 0 || lastname.length() == 0)
    {
        ui->labelInf->setText("<font color='red'>Introduceti toate datele!</font>");
        ready = false;
    }

    if(ready)
    {
        QString     send = "1_"+name+"_"+lastname+"_"+email+"_"+pass+"_"+grad+"_"+phone+"_";
        QByteArray  tmp=send.toUtf8();
        char*       sendbuff=tmp.data();


        QString recv=ConnectionSocket::getInstance()->connectServer(sendbuff);
        if(recv[0] == 'O' && recv[1] == 'k')
        {
            ui->labelInf->setText("<font color='green'>Contul a fost creat cu succes!</fon>");
            delay1(1);
            close();
            parent->show();
            delete this;
        }
        else
        {
            ui->labelInf->setText("<font color='red'>"+recv+"</font>");
        }
    }

}


void SignUpWindow::on_returnButton_clicked()
{
    close();
    parent->show();
    delete this;
}

