#include "mainmenu.h"
#include "ui_mainmenu.h"
#include "createwindow.h"
#include "announcementswindow.h"
#include "inboxwindow.h"
#include "myannounwindow.h"

#include "Cad.h"
#include <iostream>
#include <vector>


MainMenu::MainMenu(MainWindow* pa, CUser* pu, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MainMenu)
{
    ui->setupUi(this);
    this->user=pu;
    this->parent=pa;
    this->setWindowTitle("Main Menu");
    ui->labelUser->setText("Bine ai venit, <font color='red'>" + this->user->getFullname()+"</font>");
}

MainMenu::~MainMenu()
{
    delete this->user;
    delete ui;
}

void MainMenu::on_returnButton_clicked()
{
    close();
    this->parent->show();

    delete this;
}


void MainMenu::on_createButton_clicked()
{
    close();
    createWindow* window = new createWindow(this);
    window->show();
}


void MainMenu::on_anunturiButton_clicked()
{
    QString     send = "4";
    QByteArray  tmp=send.toUtf8();
    char*       sendbuff=tmp.data();
    QString recv=ConnectionSocket::getInstance()->connectServer(sendbuff);
    if(recv.length())
    {   QStringList list = recv.split("_");
        int         index=0;
        QString     tmp = list[index];
        index++;
        int         nrAnn = tmp.toInt();
        std::vector <CAd*> adds;

        QString     denumire;
        QString     locatie;
        int         idcont;
        int         id;
        QString     detalii;
        QString     data;


        for(int i=0 ; i<nrAnn; i++)
        {
            id=list[index].toInt();
            index++;
            idcont=list[index].toInt();
            index++;
            denumire = list[index];
            index++;
            detalii = list[index];
            index++;
            data = list[index];
            index++;
            locatie = list[index];
            index++;

            CAd* add = new CAd(id, denumire, locatie, detalii, idcont, data);

            adds.push_back(add);
        }

        if(adds.size())
        {
        announcementsWindow*    window = new announcementsWindow(adds, this);
        window->show();
        } else
        {
        ui->label->setText("Nu ai niciun anunt!");
        }


    }



}


void MainMenu::on_anunturileMeleButton_clicked()
{
    QString     send = "5_"+QString::number(this->user->getId())+"_";
    QByteArray  tmp=send.toUtf8();
    char*       sendbuff=tmp.data();
    QString recv=ConnectionSocket::getInstance()->connectServer(sendbuff);
    if(recv.length())
    {   QStringList list = recv.split("_");
        int         index=0;
        QString     tmp = list[index];
        index++;
        int         nrAnn = tmp.toInt();
        std::vector <CAd*> adds;

        QString     denumire;
        QString     locatie;
        int         idcont;
        int         id;
        QString     detalii;
        QString     data;


        for(int i=0 ; i<nrAnn; i++)
        {
            id=list[index].toInt();
            index++;
            idcont=list[index].toInt();
            index++;
            denumire = list[index];
            index++;
            detalii = list[index];
            index++;
            data = list[index];
            index++;
            locatie = list[index];
            index++;

            CAd* add = new CAd(id, denumire, locatie, detalii, idcont, data);

            adds.push_back(add);

        }
        close();
        myannounwindow*    window = new myannounwindow(adds, this);
        window->show();


    }
}


void MainMenu::on_inboxButton_clicked()
{
    QString     send = "7_"+QString::number(this->user->getId())+"_";
    QByteArray  tmp=send.toUtf8();
    char*       sendbuff=tmp.data();

    QString recv = ConnectionSocket::getInstance()->connectServer(sendbuff);
    QStringList list = recv.split("_");
    int var = list[0].toInt();
    if(var)
    {
        QVector<QString> tmp;
        for(int i=1; i<list.size()-1; i++)
        {
            tmp.push_back(list[i]);
        }
        close();
        inboxWindow* inbox = new inboxWindow(this, tmp);
        inbox->show();
    } else
    {
        ui->labelInbox->setText("Nu ai nicio notificare!");
    }

}

