#include "inboxwindow.h"
#include "ui_inboxwindow.h"

inboxWindow::inboxWindow(MainMenu* pm, QVector<QString> msg, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::inboxWindow)
{
    this->_msg = msg;
    this->_menu = pm;
    ui->setupUi(this);

    this->_scrollArea=ui->scrollArea;
    QWidget *scrollWidget = new QWidget(_scrollArea);
    QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);
    scrollWidget->setLayout(scrollLayout);
    _scrollArea->setWidget(scrollWidget);
    _scrollArea->setWidgetResizable(true);

    if(_msg.size())
    {
        for(int i=0; i<_msg.size(); i++)
        {
            QHBoxLayout *rowLayout = new QHBoxLayout();
            QLabel *label1 = new QLabel(_msg[i]);
            rowLayout->addWidget(label1);

            scrollLayout->addLayout(rowLayout);
        }
    }
    else
    {
        QHBoxLayout *rowLayout = new QHBoxLayout();
        QLabel *label1 = new QLabel("<font color='red'>Nu aveti nicio notificare</font>");

        rowLayout->addWidget(label1);

        scrollLayout->addLayout(rowLayout);
    }
}

inboxWindow::~inboxWindow()
{
    delete ui;
}

void inboxWindow::on_returnButton_clicked()
{
    close();

    this->_menu->show();

    delete this;
}

