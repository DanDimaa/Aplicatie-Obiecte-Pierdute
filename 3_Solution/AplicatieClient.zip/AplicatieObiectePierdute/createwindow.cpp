#include "createwindow.h"
#include "ui_createwindow.h"

createWindow::createWindow(MainMenu* p, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::createWindow)
{
    this->_menu = p;
    ui->setupUi(this);
}

createWindow::~createWindow()
{
    delete ui;
}

void createWindow::on_returnButton_clicked()
{
    close();
    this->_menu->show();
    delete this;
}


void createWindow::on_createAddButton_clicked()
{
    bool        ready=true;
    QString     locatie=ui->lineEditLocatie->text();
    QString     denumire = ui->lineEditDenumire->text();
    QString     detalii = ui->lineEditDetalii->text();

    if(locatie.length() == 0 || denumire.length()==0 || detalii.length() == 0 )
    {
        ui->label_2->setText("<font color='red'>Introduceti toate datele!</font>");
        ready=false;
    }

    if(ready)
    {
        QString     time_format = "yyyy-MM-dd  HH:mm";
        QDateTime   data = ui->dateTimeEdit->dateTime();
        QString     id = QString::number(this->_menu->getUser()->getId());
        QString     send = "3_"+id+"_"+denumire+"_"+locatie+"_"+data.toString(time_format)+"_"+detalii+"_";
        QByteArray  tmp=send.toUtf8();
        char*       sendbuff=tmp.data();

        QString recv = ConnectionSocket::getInstance()->connectServer(sendbuff);

        if(recv[0] == 'O' && recv[1] == 'k')
        {
            close();
            _menu->show();
            delete this;
        }
        else
        {
            this->ui->label_2->setText("<font color='red'>"+recv+"</font>");
        }

    }


}

