#ifndef SIGNUPWINDOW_H
#define SIGNUPWINDOW_H

#include <QDialog>
#include <QMessageBox>
#include "mainwindow.h"

namespace Ui {
class SignUpWindow;
}

class SignUpWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SignUpWindow(MainWindow* param, QWidget *parent = nullptr);
    ~SignUpWindow();

private slots:
    void on_pushButton_clicked();

    void on_returnButton_clicked();

private:

    MainWindow*     parent;
    Ui::SignUpWindow *ui;
};

#endif // SIGNUPWINDOW_H
