#ifndef MYANNOUNWINDOW_H
#define MYANNOUNWINDOW_H

#include <QDialog>
#include "mainmenu.h"
#include <QVBoxLayout>
#include <QToolButton>
#include "cad.h"
#include <iostream>
#include <vector>
#include <QRadioButton>
#include <QScrollArea>
#include <QLabel>
#include <QTextEdit>


namespace Ui {
class myannounwindow;
}

class myannounwindow : public QDialog
{
    Q_OBJECT

public:
    explicit myannounwindow(std::vector<CAd*> adds, MainMenu* pm, QWidget *parent = nullptr);
    ~myannounwindow();

private slots:
    void on_returnButton_clicked();

private:
    Ui::myannounwindow *ui;
    std::vector<CAd*> _adds;
    MainMenu*   _menu;
    QScrollArea* scrollArea;
};

#endif // MYANNOUNWINDOW_H
